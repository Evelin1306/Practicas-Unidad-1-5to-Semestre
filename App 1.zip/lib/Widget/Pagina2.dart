import 'package:flutter/material.dart';

class Pagina2 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pagina2"),
        backgroundColor: Colors.cyan, 
        ),
        body: Column(
          children: [
            Container(
              width: double.infinity,
              color:Color.fromARGB(255, 107, 195, 254),
              padding: EdgeInsets.all(25),
              child: Text("Hola Mundo",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30
              ),
              )
            ),
            Container(
              width: double.infinity,
              color:Color.fromARGB(255, 255, 255, 255),
              padding: EdgeInsets.all(25),
              child: Text("Nombre de la aplicacion",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30
               
              ),
              )
            ),
            Container(
              width: double.infinity,
              color:Color.fromARGB(255, 78, 66, 1),
              padding: EdgeInsets.all(25),
              child: Text("Notas",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30
              ),
              )
            )
          ],
        ),
      );
  }
}