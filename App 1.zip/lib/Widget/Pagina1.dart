import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Pagina1 extends StatelessWidget{
  const Pagina1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Practica 1',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontFamily: 'Times New Roman',
          ), // TextStyle
        ), // Text
        backgroundColor: const Color.fromARGB(255, 220, 105, 246),
      ), // AppBar
      body: Column(
        children: [
          Text('Hola mundo',
            style: TextStyle(
              fontFamily: "Arial Corriel",
              fontSize: 30,
              color: Colors.pinkAccent,
            ), // TextStyle
          ), // Text
          FloatingActionButton(
            onPressed: (){},
            child: Text('aceptar'),
          ), // FloatingActionButton
        ],
      ), // Column
    ); // Scaffold
  }
}
