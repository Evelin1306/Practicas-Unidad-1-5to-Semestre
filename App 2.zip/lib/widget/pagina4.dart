import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class pagina4 extends StatelessWidget{
  void accion(){
    print('Hola Mundo');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('login'),
        backgroundColor:Color.fromARGB(255, 89, 108, 158),
      ),
      body:Column(
        children: [
          Expanded(
            flex: 5,
            child: Container(
              width: double.infinity,
              color: const Color.fromARGB(255, 115, 116, 112),
             child: Container(
                  padding: EdgeInsets.all(25),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextField(
                         keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: 'Usuario',
                          
                        ),
                      ),
                      SizedBox(height: 15,
                      ),
                      TextField(
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Password',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          Expanded(
            flex: 1,
            child: Container(
              color: const Color.fromARGB(255, 97, 89, 89),
              padding: EdgeInsets.only(left: 5,right: 5,top: 15,bottom: 25),
              width: double.infinity,
              child: ElevatedButton(
                onPressed: accion, 
                child: Text('Aceptar')
                ),
            ),
            ),
      ]
      ),

    );
  }
}