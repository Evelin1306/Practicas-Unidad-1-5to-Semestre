import 'package:flutter/material.dart';

class Pagina2 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('pagina 2'),
        backgroundColor: const Color.fromARGB(255, 28, 80, 170),
      ),
      body:Column(
        children:[
          Expanded(
            child: Container(
              width: double.infinity,
              color: Colors.cyan,
              padding: EdgeInsets.all(25),
              child: Text('Hola Mundo',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                ),
              ),
            ),
          ),
        Expanded(
          child: Container(
              width: double.infinity,
              color: const Color.fromARGB(255, 7, 34, 38),
              padding: EdgeInsets.all(25),
              child: Text('Nombre de la aplicacion',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                color: Colors.pinkAccent,
                ),
              ),
            ),
        ),
        Expanded(
          child: Container(
              width: double.infinity,
              color: const Color.fromARGB(255, 7, 34, 38),
              padding: EdgeInsets.all(25),
              child: Text('Notas',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                color: Colors.pinkAccent,
                ),
              ),
            ),
        ),
        
        

        ],
      )
    );

  }
}