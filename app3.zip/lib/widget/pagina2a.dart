// Pagina2.dart
import 'package:flutter/material.dart';
//import 'package:app_3/widget/pagina3.dart';

class pagina2a extends StatefulWidget {
    final String usuario2;
    final String password2;
  const pagina2a( {super.key,
  required this.usuario2,
  required this.password2,
  });

    @override
    State<StatefulWidget> createState() {
        return Otra();
    }
}
class Otra extends State<pagina2a> {
    @override
    Widget build(BuildContext context) {
        return Scaffold(
            appBar: AppBar(
                title: Text('Pagina 2',
                style: TextStyle(
                  color: const Color.fromARGB(255, 103, 180, 242)
                ),),
                backgroundColor: Colors.grey,
            ),
            body: Center(
              child: Column(
                children: [
                  Text("Usuario:${widget.usuario2}"),
                  Text("Password:${widget.password2}")
                ],
              ),
            ),
        );
    }
}
