// Pagina2.dart
import 'package:app_3/widget/pagina2a.dart';
import 'package:flutter/material.dart';
//import 'package:app_3/widget/pagina3.dart';

class Pagina1 extends StatefulWidget {
  const Pagina1({super.key,
  });

    @override
    State<StatefulWidget> createState() {
        return Disenio();
    }
}
class Disenio extends State<Pagina1> {
  final TextEditingController Usuario =TextEditingController();
  final TextEditingController Password =TextEditingController();
  void Enviar(){
    final String u = Usuario.text;
    final String p = Password.text;
    setState(() {
      Navigator.push(//Envia a otra pagina con felechita para retornar
      //Navigator.pushReplacement( //Envia a otra pagina sin flechita de retorno
        context,  
        MaterialPageRoute(  
            builder:(context) => pagina2a(usuario2: u, password2: p),  
        )
      );  
    });
  }
    @override
    Widget build(BuildContext context) {
        return Scaffold(
            appBar: AppBar(
                title: Text('Pagina 1',
                    style: TextStyle(
                        color: Colors.white,
                    ),
                ),
                backgroundColor: Colors.blue,
            ),
            body: Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                      Center(
                          child: Text('Login'),
                      ),
                      SizedBox(
                          height: 20,
                      ),
                      TextField(
                        controller: Usuario,
                        decoration: InputDecoration(
                          labelText: 'Usuario'
                        ),
                      ),
                      TextField(
                        controller: Password,
                        decoration: InputDecoration(
                          labelText: 'Password'
                        ),
                      ),
                      SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              onPressed: Enviar,
                              child: Text('Aceptar'),
                          ),
                      ),
                  ],
              ),
            ),
        );
    }
}