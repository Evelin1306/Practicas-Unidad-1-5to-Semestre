import 'package:flutter/material.dart';
import 'package:app_2/widget/pagina6.dart';

class Pagina5 extends StatefulWidget{
  @override
  State<StatefulWidget> createState(){
    return Disenio();
  }
}
class Disenio extends State<Pagina5>{
  final TextEditingController Usuario = TextEditingController();
  final TextEditingController Password = TextEditingController();

  String res = 'Sin acción';

  void accion(){
    final String us = Usuario.text;
    //final String pas = Password.text;
    final int pas = int.tryParse(Password.text)?? 0;
  
    setState(() {
      if (us == "admin" && pas == 123){
        res = "Usuario y password correcto";
        Navigator.push(context,
         MaterialPageRoute(
          builder: (context) =>Pagina6(
            nombre: us,
          )
          )
          );
      }else{
        //res = "Usuario y password incorrectos";
        showDialog(
          context: context,
          builder:(context){
            return AlertDialog(
              title: Text("Error de acceso"),
              content: Text("Usuario y/o password incorrecctos"),
              actions: [
                TextButton(
                  onPressed: (){
                    Navigator.pop(context);
                  },
                  child: Text('Aceptar'),
                )
              ],
            );
          }
        );
      }
    
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        children: [
            Expanded(
              flex: 5, 
              child: Container(
                width: double.infinity,
                color: const Color.fromARGB(255, 72, 211, 197),
                child: Container(
                  padding: EdgeInsets.all(25),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextField(
                        controller: Usuario,
                         keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: 'Usuario',
                        ),
                      ),
                      SizedBox(height: 15,
                      ),
                      TextField(
                        controller: Password,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Password',
                        ),
                      ),
                      SizedBox(height: 15,
                      ),
                      Text ('$res'),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                color: const Color.fromARGB(255, 72, 211, 197),
                padding: EdgeInsets.only(left: 5, right: 5,top: 15, bottom: 25),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: accion,
                  child: Text('Aceptar')
                ),
              )  
            )
        ],
      ),
    );
  }
}