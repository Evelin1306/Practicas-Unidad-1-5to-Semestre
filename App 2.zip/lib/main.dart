import 'package:app_2/widget/pagina1.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_practica1_1/widget/pagina1.dart';
import 'package:app_2/widget/pagina2.dart';
import 'package:app_2/widget/pagina3.dart';
import 'package:app_2/widget/pagina4.dart';
import 'package:app_2/widget/pagina5.dart';
import 'package:app_2/widget/pagina6.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Pagina5(),
    );// MaterialApp
  }
}

