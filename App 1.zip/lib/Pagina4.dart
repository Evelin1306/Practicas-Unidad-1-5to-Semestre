import 'package:flutter/material.dart';

class Pagina4 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: Text("Hola"),
          )        
        ],
      ),
    );
  }

}