import 'package:flutter/material.dart';

class pagina3 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('pagina 3'),
        backgroundColor: const Color.fromARGB(255, 28, 80, 170),
      ),
      body:Column(
        children:[
          Expanded(
            flex:3,
            child: Container(
              width: double.infinity,
              color: Colors.cyan,
              padding: EdgeInsets.all(25),
              child: Text('Hola Mundo',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                ),
              ),
            ),
          ),
        Expanded(
          flex:1,
          child: Container(
              width: double.infinity,
              color: const Color.fromARGB(255, 166, 173, 174),
              padding: EdgeInsets.all(25),
              child: Text('Nombre de la aplicacion',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                color: Colors.pinkAccent,
                ),
              ),
            ),
        ),
        Expanded(
          flex:3,
          child: Container(
              width: double.infinity,
              color: const Color.fromARGB(255, 193, 206, 208),
              padding: EdgeInsets.all(25),
              child: Text('Notas',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                color: const Color.fromARGB(255, 181, 90, 120),
                ),
              ),
            ),
        ),
        
        

        ],
      )
    );

  }
}